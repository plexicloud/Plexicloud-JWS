<?php
class JWS_auth_Exception extends Exception
{
	
}
