<?php
include 'standalone.php';



?>