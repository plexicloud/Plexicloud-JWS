<?php
/**
 * Joomla! 1.5 component jws
 *
 * @version $Id: controller.php 2010-05-27 10:39:17 svn $
 * @author Sudhi
 * @package Joomla
 * @subpackage jws
 * @license GNU/GPL
 *
 * Joomla Webservices
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.controller' );
require_once( JPATH_COMPONENT.DS.'helpers'.DS.'helper.php' );

/**
 * jws Controller
 *
 * @package Joomla
 * @subpackage jws
 */
class JwsController extends JController {
    /**
     * Constructor
     * @access private
     * @subpackage jws
     */
    function __construct() {
        //Get View
        if(JRequest::getCmd('view') == '') {
            JRequest::setVar('view', 'default');
        }
        $this->item_type = 'Default';
        parent::__construct();
    }
	
	function installWS() {
		//Read the script file and execute
		jimport('joomla.filesystem.file');
		jimport('joomla.filesystem.folder');	
		$sql = JFile::read(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jws'.DS.'jws_files'.DS.'scripts'.DS.'database'.DS.'ws_create.sql');
		
		$db= &Jfactory::getDBO();
		$db->setQuery($sql);
		
		$db->query();
		echo "<br /> DB tables installed..<br />";
		
		//backup files.
		echo "<br /> Backing up files..Renaming...<br />";
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'user'.DS.'view.html.php', 
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'user'.DS.'view.html.php.jws');
					
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'user'.DS.'tmpl'.DS.'form.php',
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'user'.DS.'tmpl'.DS.'form.php.jws');
		
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'controller.php',
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'controller.php.jws');
					
		echo '<br /> Copying Files...<br/>';
		
		/*JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jws'.DS.'jws_files'.DS.'administrator'.DS.'components'.DS.'com_users'.DS.'views'.DS.'user'.DS.'view.html.php', 
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'user'.DS.'view.html.php');
					
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jws'.DS.'jws_files'.DS.'administrator'.DS.'components'.DS.'com_users'.DS.'views'.DS.'tmpl'.DS.'form.php',
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'tmpl'.DS.'form.php');
		
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jws'.DS.'jws_files'.DS.'administrator'.DS.'components'.DS.'com_users'.DS.'controller.php',
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'controller.php');
					
		
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jws'.DS.'jws_files'.DS.'standalone.php',JPATH_SITE);
		
		JFolder::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jws'.DS.'jws_files'.DS.'api',JPATH_SITE );
		
		$db = & JFactory::getDBO();


		$sql = "select count(id) from #__components where `option`='com_community'";

		$db->setQuery($sql);

		$result = $db->loadResult();

		If($result > 0) {
			echo '<br/> Jom social Installed <br/>';
			echo "<br /> Backing up files..Renaming...<br />";
			JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_community'.DS.'config.xml',
						JPATH_ADMINISTRATOR.DS.'components'.DS.'com_community'.DS.'config.xml.jws');
			
			JFile::copy(JPATH_SITE.DS.'components'.DS.'com_community'.DS.'templates'.DS.'default'.DS.'profile.preferences.php',
						JPATH_SITE.DS.'components'.DS.'com_community'.DS.'templates'.DS.'default'.DS.'profile.preferences.php.jws');
			
			echo '<br /> Copying Files...<br/>';		
			JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jws'.DS.'jws_files'.DS.'administrator'.DS.'components'.DS.'com_community'.DS.'config.xml',
						JPATH_ADMINISTRATOR.DS.'components'.DS.'com_community'.DS.'config.xml');
			JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jws'.DS.'jws_files'.DS.'components'.DS.'com_community'.DS.'templates'.DS.'default'.DS.'profile.preferences.php',
						JPATH_SITE.DS.'components'.DS.'com_community'.DS.'templates'.DS.'default'.DS.'profile.preferences.php');
			
		}*/
		
		
	}
	
	function unInstallWS() {
		//Read the script file and execute
		jimport('joomla.filesystem.file');
		jimport('joomla.filesystem.folder');	
		$sql = JFile::read(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_jws'.DS.'jws_files'.DS.'scripts'.DS.'database'.DS.'ws_drop.sql');
		
		$db= &Jfactory::getDBO();
		$db->setQuery($sql);
		
		$db->query();
		echo "<br /> DB tables installed..<br />";
		
		//backup files.
		/*echo "<br /> Backing up files..<br />";
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'user'.DS.'view.html.php', 
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'user'.DS.'view.html.php.jws');
					
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'tmpl'.DS.'form.php',
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'tmpl'.DS.'form.php.jws');
		
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'controller.php',
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'controller.php.jws');
					
		echo '<br /> Copying Files...<br/>';
		
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'jws_files'.DS.'administrator'.DS.'components'.DS.'com_users'.DS.'views'.DS.'user'.'view.html.php', 
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'user'.'view.html.php');
					
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'jws_files'.DS.'administrator'.DS.'components'.DS.'com_users'.DS.'views'.DS.'tmpl'.'form.php',
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'views'.DS.'tmpl'.'form.php');
		
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'jws_files'.DS.'administrator'.DS.'components'.DS.'com_users'.DS.'controller.php',
					JPATH_ADMINISTRATOR.DS.'components'.DS.'com_users'.DS.'controller.php');
					
		
		JFile::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'jws_files'.DS.'standalone.php',JPATH_SITE);
		
		JFolder::copy(JPATH_ADMINISTRATOR.DS.'components'.DS.'jws_files'.DS.'api',JPATH_SITE );
		*/
	}
}
?>